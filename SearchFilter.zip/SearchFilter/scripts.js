console.log('extention works')
const hindiChars = /[अआइईउऊएऐओऔअंअःऋॠकखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसहक्षत्रज्ञਸੀਬੋਦਾਨੀਸਰਦਾ]/
const words = new Set(['hindi', 'indian', 'episode', 'pig']);
const emoji = /([\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff]|{Emoji}])/gi;
const alfa =  /[\w\s\d\p,./!@#$%^&*()_-\|]+/g;
list = [];

function filter () {
    for (const card of document.querySelectorAll('ytd-rich-item-renderer, ytd-compact-video-renderer, ytd-playlist-panel-video-renderer')) {
        var text = card.textContent.toString().toLowerCase();
        var hindi = hindiChars.test(text);
        var alpha = alfa.test(text);
        var emo = emoji.test(text);
        for (i of words) {
            wordIndex = text.indexOf(i)
            if (hindi === true || wordIndex >= 0 || alpha === false || emo === true) {
                card.style.display = "none";
            }
        }
    }
};

chrome.runtime.onMessage.addListener(gotMessage);
function gotMessage(message, sender, sendResponse) {
    console.log(message.txt);
}

function addToList(list) {
    // list.append(list)
    console.log(list);
};

let message = 'this is msg'
chrome.runtime.sendMessage(message);

var ScrollDebounce = true;
document.addEventListener('scroll',
    function () {
        if (ScrollDebounce) {
            ScrollDebounce = false;
            filter();
            setTimeout(function () { ScrollDebounce = true; }, 1500);
        }
    });
