console.log('background running');

// chrome.runtime.onMessage.addlistener(receiver);

// function receiver(request) {
//     console.log(request);
// }

chrome.action.onClicked.addListener(buttonCliked);
function buttonCliked(tab) {
    let msg = {
        txt : "hello"
    }
    chrome.tabs.sendMessage(tab.id, msg);
    console.log(tab);
}